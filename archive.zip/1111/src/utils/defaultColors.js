export const DEFAULT_COLORS = [
  '#60b8f6', '#55da8d', '#ffcc41',
  '#ba5eed', '#ff6e8c', '#1f9bff',
  '#e1017e', '#e7641c', '#c1df05',
  '#00acc5', '#de0029', '#02af3b',
  '#c23531', '#2f4554', '#ca8622',
  '#7ec720', '#3c117c', '#0168b3'
]
