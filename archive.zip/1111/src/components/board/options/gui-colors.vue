<template>
  <div class="gui-color">
    <slot></slot>
  </div>
</template>

<script>
  export default {}
</script>
