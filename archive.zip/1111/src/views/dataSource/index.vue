<template>
  <div class="screen-manage">
    <router-view></router-view>
  </div>
</template>
