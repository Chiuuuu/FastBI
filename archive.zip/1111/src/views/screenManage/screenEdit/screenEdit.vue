<template>
  <div class="screen-edit">
    <div class="header">
      <div class="header-title">电视统计大屏</div>
      <div class="header-center">
        <ul>
          <li>
            <a-icon type="bar-chart" />
            <p>添加图表</p>
          </li>
          <li>
            <a-icon type="font-size" />
            <p>添加文本</p>
          </li>
        </ul>
      </div>
      <div class="header-right">
        <div class="item">
          <a-icon type="border" />
          <p>预览</p>
        </div>
        <div class="item">
          <a-icon type="close" />
          <p>退出</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style lang="styl" scoped>
@import "./screenEdit.styl";
</style>
